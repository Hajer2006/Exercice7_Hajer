<!DOCTYPE html>


<html lang="fr"> <!-- Déclaration du type de document et de la langue principale pour l'accessibilité et le SEO -->


<head>


  <meta charset="utf-8"> <!-- Encodage UTF-8 pour gérer correctement les accents et caractères spéciaux -->


  <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Permet un affichage adapté sur mobile et tablettes -->


  <meta name="description" content="Présentation de ma passion pour l'art : calligraphie arabe et art minimaliste.">



  <!-- Balises Open Graph pour réseaux sociaux -->


  <meta property="og:title" content="Ma passion pour l'art !">


  <meta property="og:description" content="Présentation de ma passion pour l'art : calligraphie arabe et art minimaliste.">


  <meta property="og:image" content="IMG_2562.jpeg">


<meta property="og:type" content="website">


  <meta property="og:url" content="https://hajer.infinityfree.me/art_site/">



  <title>Ma passion pour l'art !</title>



  <!-- CSS interne -->


  <style>


    /* --- Corps de la page --- */


body {


  font-family: Georgia, serif; /* Police simple et lisible */


  background-color: #BC8F8F; /* Couleur rose nude pour le fond */


  margin: 20px; /* Marge autour de la page */


}



/* --- Menu vertical --- */


nav {


  width: 200px; /* Largeur fixe pour le menu */


  float: left; /* Permet au menu de flotter à gauche du contenu */


  background-color: #C5A0A7; /* Couleur assortie au thème général */


  padding: 20px; /* Espace intérieur */


  margin-right: 20px; /* Espace entre menu et contenu principal */


border-radius: 5px; /* Coins arrondis pour un style doux */


}



nav ul {


  list-style-type: none; /* Supprime les puces par défaut */


padding: 0; /* Supprime le padding par défaut */


}



nav ul li {


  margin-bottom: 10px; /* Espace entre les liens du menu */


}



nav ul li a {


  text-decoration: none; /* Supprime le soulignement par défaut */


  color: #906E74; /* Couleur des liens */


  font-weight: bold; /* Texte en gras pour les liens */


}



nav ul li a:hover {


  color: #704C52; /* Couleur au survol pour indiquer l'interaction */



}



/* --- Lettrine --- */


.lettrine {


  font-size: 450%; /* Taille plus grande pour mettre en valeur la première lettre */


  float: left; /* La lettre flotte à gauche du texte */


line-height: 0.9; /* Ajuste la hauteur pour que la lettrine s'aligne bien avec le texte */


margin: -0.2em 0.02em 0 0; /* Alignement harmonieux */


  color: #A97882; /* Couleur douce et assortie au thème */


}



/* --- Conteneur principal --- */


main {


  overflow: hidden; /* Empêche le chevauchement avec le menu flottant */


margin-left: 270px; /* Laisse de l'espace entre le menu et le texte */


}



/* --- Div pour regrouper les sections --- */


.section-box {


  background-color: #f5e6e7; /* Couleur rose très clair pour différencier les sections */


padding: 15px; /* Espace intérieur confortable */


  margin-bottom: 20px; /* Espace entre les sections */


  border-radius: 8px; /* Coins arrondis pour un style doux */


  clear: both; /* Assure que les sections ne chevauchent pas les éléments flottants */


  border: 1px solid #b08287; /* Bordure assortie au menu pour cohérence visuelle */


}



/* --- Span pour surligner ou mettre en valeur certains mots --- */


.highlight {


  color: #805c6c; /* Couleur foncée pour contraste avec le texte principal */


  font-weight: bold; /* Texte en gras pour accentuer */


}


/* --- Images --- */


img {


  float: left; /* Permet aux images de flotter et au texte de s'enrouler autour */


  margin: 10px; /* Espace autour des images */


  max-width: 200px; /* Taille images moyenne afin de garder l'harmonie de la page */


  border-radius: 5px; /* Coins légèrement arrondis pour un style doux */


}


/* --- Footer --- */


footer {


  text-align: center; /* Centre le texte du footer */


  padding: 15px; /* Espace intérieur */


  background-color: #C5A0A7; /* Couleur assortie au menu pour uniformité */


  color: #f5e6e7; /* Texte clair pour contraste avec le fond */


border-radius: 5px; /* Coins arrondis pour style doux */


  clear: both; /* Assure que le footer ne chevauche pas les éléments flottants */


}



/* --- TITRE CENTRÉ ET COULEUR --- */


header h1 {


text-align: center;


  color: #704C52;


}


.form-title {

    color: #black;         /* Couleur simple */

    text-align: center;     /* Centre le texte horizontalement */

    margin-bottom: 15px;    /* Petit espace sous le titre */

    font-size: 1.6em;       /* Taille légèrement plus grande */

    font-weight: bold;      /* Texte en gras */

    font-family: Georgia, serif;  /* Même police que le reste de la page */

    border-bottom: 2px solid #b08287;  /* Petite ligne sous le titre */

    display: inline-block;   /* La bordure ne s'étend pas sur toute la largeur */

    padding-bottom: 5px;     /* Espace entre le texte et la ligne */

}



#formulaire {

    background-color: #f5e6e7; /* Rose clair assorti */

    padding: 20px;

    border-radius: 10px;

    border: 1px solid #b08287;

    box-shadow: 2px 2px 8px rgba(0,0,0,0.1);

}


/* Bouton envoyer de couleur rose */

input[type="submit"] {

    cursor: pointer;

    background-color: #704C52; /* rose assorti au thème */

    color: #fff;               /* texte blanc */

    border: none;

    padding: 10px 20px;

    border-radius: 5px;

}


</style>


</head>



<body>


<header>


  <h1>Ma passion pour l'art !</h1>


</header>



<!-- Menu vertical -->


<nav>


  <ul>


    <li><a href="#presentation">Présentation</a></li>


    <li><a href="#collages">Collages</a></li>


    <li><a href="#inspiration">Liens Inspiration</a></li>


    <li><a href="https://hajer.infinityfree.me/" target="_blank">Ancienne page</a></li>


  </ul>


</nav>


<!-- Contenu principal -->


<main> 



  <!-- Section de présentation -->


  <div class="section-box" id="presentation">


    <h2>Présentation de ma passion</h2>


    <p><span class="lettrine">J</span>’ai toujours aimé l’art, le dessin et la peinture, mais je ne m’étais jamais vraiment


lancée. En naviguant sur les réseaux sociaux, notamment Pinterest, j’ai découvert de nombreuses créations qui


      m’ont inspirée, comme les <span class="highlight"> toiles de calligraphie arabe</span> et les <span class="highlight"> toiles minimalistes. </span></p>


    <p>Un jour, je me suis dit « Pourquoi pas ? » et j’ai voulu essayer. Je suis encore très débutante, mes créations


      ne sont pas parfaites, mais ça me passionne vraiment et je prends beaucoup de plaisir dans ce que je fais.</p>



    <p>J’aime particulièrement créer des toiles de calligraphie arabe, où je peux calligraphier des mots, des prénoms ou 


des citations inspirantes. C’est un art que j’apprécie beaucoup.</p>



    <p>Je m’intéresse aussi à l’art minimaliste, notamment les toiles arc-en-ciel réalisées avec de l’enduit (rainbow plaster art en anglais). C’est un type d’art un peu particulier, qui se fait avec de l’enduit pour créer du relief et des textures (textured art en anglais). Ce que j’aime dans cet art, c’est qu’on peut faire ce qu’on veut, sans chercher la perfection.


      Chaque œuvre est unique, avec ses reliefs et irrégularités.</p>


  <p>Pour montrer ce que je fais, j’ai réalisé deux collages : le premier rassemble mes propres créations, et le


      second présente mes inspirations, c’est à dire le style et la qualité que j’aimerais atteindre dans mes travaux de calligraphie arabe et d’art minimaliste.</p>


  <p>Par la suite, j’aimerais découvrir d’autres types d’art, comme la peinture acrylique, pour réaliser des œuvres


      réalistes, comme des paysages ou des portraits.</p>


  </div>


<!-- Section collages -->


  <div class="section-box" id="collages">


    <h2>Collage créations et inspirations</h2>


    <img src="IMG_2562.jpeg" alt="Collage créations">


    <img src="IMG_2579.jpeg" alt="Collage inspirations">


  </div>



  <!-- Section liens inspiration -->


  <div class="section-box" id="inspiration">


    <h2>Liens Inspiration</h2>


    <p>


      <a href="https://youtu.be/Slw-nAtpBck?si=3H-FjI1eIS0KS-ML" target="_blank">[Calligraphie] Citation en arabe – Espoir – YouTube</a><br>


    <a href="https://youtu.be/ElYHtkk7LRk?si=-GbtfHStvN9uEGmh" target="_blank">DIY Textured Art on Canvas - YouTube</a>


</p>

</div>


<!-- Intro formulaire -->

<div class="section-box" id="intro-formulaire">

  <p>

    Merci d’avoir lu jusqu’ici ! Si vous aimez aussi l’art, 

    remplissez ce petit formulaire pour me dire vos goûts, vos inspirations, et donner une note 

    à trois œuvres célèbres 🎭.

  </p>

</div>


<!-- Formulaire -->

<div class="section-box" id="formulaire">

    <h2 class="form-title">🎨 Partage ta passion artistique</h2>

    <form action="traitement.php" method="post" style="margin-top:15px;">

        <label for="nom">Votre nom :</label>

        <input type="text" name="nom" id="nom" placeholder="Ex: Michel Dupont" required style="width:100%; padding:5px; margin-top:5px;">


        <label for="email">Votre email :</label>

      <input type="email" name="email" id="email" placeholder="Ex: monemail@email.com" required style="width:100%; padding:5px; margin-top:5px;">


        <label for="type_art">Type d'art préféré :</label>

        <select name="type_art" id="type_art" required style="width:100%; padding:5px; margin-top:5px;">

          <option value="">--Sélectionnez votre type d'art préféré--</option>

            <option value="Calligraphie">Calligraphie</option>

            <option value="Minimaliste">Minimaliste</option>

            <option value="Impressionnisme">Impressionnisme</option>

            <option value="Cubisme">Cubisme</option>

            <option value="Surréalisme">Surréalisme</option>

            <option value="Art abstrait">Art abstrait</option>

            <option value="Aquarelle">Aquarelle</option>

            <option value="Peinture acrylique">Peinture acrylique</option>

            <option value="Street Art">Street Art</option>

            <option value="Photographie">Photographie</option>

        </select>


        <label for="support">Support préféré :</label>

        <input type="text" name="support" id="support" placeholder="Toile, papier, bois, Carton, verre, mural, numérique" required style="width:100%; padding:5px; margin-top:5px;">


        <label for="couleur">Couleur favorite :</label>

        <input type="text" name="couleur" id="couleur" placeholder="Noir, Blanc, Rouge, Bleu, Vert, Jaune, Rose, Violet, Gris, Marron, Orange" required style="width:100%; padding:5px; margin-top:5px;">


      <label for="date">Date de participation (JJ/MM/AAAA) :</label>

<input type="date" name="date" id="date" required style="width:100%; padding:5px; margin-top:5px;">


        <label style="margin-top:10px;">Notez ces 3 œuvres célèbres (1 à 5) :</label>


        <div style="margin-top:10px;">

            <p>La Nuit étoilée (Van Gogh) :</p>

            <img src="IMG_2797.jpeg" alt="La Nuit étoilée" style="max-width:200px; display:block; margin-bottom:5px;">

            <input type="number" name="note_1" id="note_1" min="1" max="5" required style="width:100%; padding:5px; margin-bottom:10px;">

        </div>


        <div>

            <p>Les Nymphéas (Monet) :</p>

            <img src="IMG_2798.jpeg" alt="Les Nymphéas" style="max-width:200px; display:block; margin-bottom:5px;">

            <input type="number" name="note_2" id="note_2" min="1" max="5" required style="width:100%; padding:5px; margin-bottom:10px;">

        </div>


        <div>

            <p>Le Cri (Munch) :</p>

            <img src="IMG_2799.jpeg" alt="Le Cri" style="max-width:200px; display:block; margin-bottom:5px;">

            <input type="number" name="note_3" id="note_3" min="1" max="5" required style="width:100%; padding:5px; margin-bottom:10px;">

        </div>


        <input type="submit" value="Envoyer">

    </form>

</div>


  <!-- Section conclusion -->


  <div class="section-box" id="conclusion">


    <h2>Conclusion</h2>


    <p>C’est ainsi que se termine ce petit aperçu de ma passion pour l’art.</p>


  </div>



</main>


<!-- Footer -->


<footer>


  &copy; 2025 Ma Passion pour l'art. Tous droits réservés. <!-- Pied de page avec copyright --> 


</footer>



</body>


</html>