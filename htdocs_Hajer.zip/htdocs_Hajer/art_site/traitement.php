<?php

// ======= AFFICHAGE DES ERREURS POUR DÉBOGAGE =======

ini_set('display_errors', 1);

ini_set('display_startup_errors', 1);

error_reporting(E_ALL);


// ======= CONFIGURATION MYSQL =======

$host = "sql100.infinityfree.com";  // serveur MySQL InfinityFree

$user = "if0_40190486";             // nom utilisateur MySQL

$pass = "6QqQ2Ph7Yq";            // mot de passe MySQL

$dbname = "if0_40190486_artdb";     // nom base


// Connexion

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {

    die("Connexion échouée : " . $conn->connect_error);

}


// ======= FONCTION DE NETTOYAGE =======

function nettoyer($x){

    return htmlspecialchars(stripslashes(trim($x)));

}


// ======= RÉCUPÉRATION DES DONNÉES =======

$nom = isset($_POST['nom']) ? nettoyer($_POST['nom']) : '';

$email = isset($_POST['email']) ? nettoyer($_POST['email']) : '';

$type_art = isset($_POST['type_art']) ? nettoyer($_POST['type_art']) : '';

$support = isset($_POST['support']) ? nettoyer($_POST['support']) : '';

$couleur = isset($_POST['couleur']) ? nettoyer($_POST['couleur']) : '';

$date_creation = isset($_POST['date']) ? $_POST['date'] : null;

$note_1 = isset($_POST['note_1']) ? (int)$_POST['note_1'] : 0;

$note_2 = isset($_POST['note_2']) ? (int)$_POST['note_2'] : 0;

$note_3 = isset($_POST['note_3']) ? (int)$_POST['note_3'] : 0;


// ======= INSERTION DANS LA BASE =======

$sql = "INSERT INTO avis_art 

(nom, email, type_art, support, couleur, date_creation, note_1, note_2, note_3) 

VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);


if ($stmt === false) {

    die("Erreur préparation : " . $conn->error);

}


$stmt->bind_param("ssssssiii", $nom, $email, $type_art, $support, $couleur, $date_creation, $note_1, $note_2, $note_3);

if(!$stmt->execute()) {

    die("Erreur exécution : " . $stmt->error);

}


// ======= MESSAGE DE CONFIRMATION =======

echo "<h1>Merci pour votre participation, $nom !</h1>";


// ======= AFFICHAGE DE TOUTES LES PARTICIPATIONS =======

$result = $conn->query("SELECT * FROM avis_art ORDER BY date_envoi DESC");

if ($result && $result->num_rows > 0) {

    echo "<h2>Toutes les participations :</h2>";

    echo "<table border='1' cellpadding='5' cellspacing='0'>";

    echo "<tr>

            <th>Nom</th>

            <th>Email</th>

            <th>Type d'art</th>

            <th>Support</th>

            <th>Couleur</th>

            <th>Date création</th>

            <th>La Nuit étoilée</th>

            <th>Les Nymphéas</th>

            <th>Le Cri</th>

            <th>Envoyé le</th>

          </tr>";

    while($row = $result->fetch_assoc()) {

        echo "<tr>";

        echo "<td>".htmlspecialchars($row['nom'])."</td>";

        echo "<td>".htmlspecialchars($row['email'])."</td>";

        echo "<td>".htmlspecialchars($row['type_art'])."</td>";

        echo "<td>".htmlspecialchars($row['support'])."</td>";

        echo "<td>".htmlspecialchars($row['couleur'])."</td>";

        echo "<td>".htmlspecialchars($row['date_creation'])."</td>";

        echo "<td>".$row['note_1']."</td>";

        echo "<td>".$row['note_2']."</td>";

        echo "<td>".$row['note_3']."</td>";

        echo "<td>".$row['date_envoi']."</td>";

        echo "</tr>";

    }

    echo "</table>";

} else {

    echo "<p>Aucune participation enregistrée pour le moment.</p>";

}


// ======= FERMETURE =======

$stmt->close();

$conn->close();

?>