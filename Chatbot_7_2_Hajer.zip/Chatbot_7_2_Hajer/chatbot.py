import tkinter as tk   # Importe la bibliothèque Tkinter et lui donne le raccourci "tk" pour créer l’interface graphique

from PIL import Image, ImageTk   # Importe les outils de la bibliothèque PIL pour ouvrir et afficher des images dans Tkinter


# Dictionnaire des réponses, chaque mot ou phrase clé correspond à la réponse que le bot donnera

responses = {

# Si l'utilisateur écrit "bonjour", le bot répondra par cette phrase

"bonjour": "Bonjour je suis Mango, je suis là pour t’aider !",

# Si l'utilisateur écrit "bonsoir", le bot répondra par cette phrase

    "bonsoir": "Bonsoir, j’espère que tu as passé une bonne journée !",

# Si l'utilisateur écrit "recette" dans sa phrase le bot donnera cette idée de recette

    "recette": (

        "Oui ! Essaie de faire un cheesecake à la mangue. "

        "C’est rapide, frais et délicieux : une base de biscuits, une crème au fromage, et un coulis à la mangue."

    ),

# Si l'utilisateur écrit "livre" dans sa phrase le bot donnera cette réponse 

    "livre": (

        "Tu pourrais lire Toutes ses fautes d’Andrea Mara. "

        "C’est l’histoire d’un petit garçon disparu et des secrets qu’on découvre en cherchant la vérité…"

    ),

# Si l'utilisateur demande "quelle est ta peinture préférée", le bot répondra sa peinture

    "quelle est ta peinture préférée": "Ma peinture préférée est La Nuit étoilée de Van Gogh.",

# Si l'utilisateur demande "qui a peint la joconde", le bot répondra le nom de l’artiste

    "qui a peint la joconde": "C’est Léonard de Vinci qui a peint La Joconde !",

# Si l'utilisateur demande "tu préfères quelle saison", le bot répondra sa saison préférée

    "tu préfères quelle saison": "Le printemps, c’est la saison du renouveau et des fleurs."

}


# Pour les deux questions contenant les mots "recette" et "livre", le bot envoie en plus des réponses une image, une photo pour montrer à quoi ressemble le dessert et une image pour illustrer le livre

images = {

    "recette": "IMG_2994.jpeg",

    "livre": "IMG_2995.jpeg"

}


# Fonction pour obtenir la réponse du bot selon ce que l'utilisateur écrit

def get_response(user_msg):

# Met tout en minuscules et enlève les espaces au début et à la fin

    msg = user_msg.lower().strip()

# Choisit la réponse selon le mot clé dans le message

    if "recette" in msg: # Si le mot "recette" est présent

        key = "recette"

    elif "livre" in msg: # Si le mot "livre" est présent

        key = "livre"

    elif "bonjour" in msg: # Si l'utilisateur dit "bonjour"

        key = "bonjour" 

    elif "bonsoir" in msg: # Si l'utilisateur dit "bonsoir"

        key = "bonsoir"

    elif "peinture" in msg: # Si l'utilisateur parle de peinture

        key = "quelle est ta peinture préférée"

    elif "joconde" in msg: # Si l'utilisateur parle de la Joconde 

        key = "qui a peint la joconde"

    elif "saison" in msg: # Si l'utilisateur parle de saison

        key = "tu préfères quelle saison"

    else:

        # Si aucun mot clé n'est trouvé 

        return "Désolé, je ne comprends pas ta question…", None


# Permet de retourner la réponse dans le dictionnaire responses

    # et l'image dans le dictionnaire images (Si il y’a aucune image None)

    return responses[key], images.get(key, None)


# Fonction qui crée une bulle de message (rectangulaire) dans le chat

# text : le message à afficher 

# sender : "bot" ou "user", pour savoir qui envoie le message

# pdp_file : le fichier de l'image de profil

# image_file : image en plus du message (recette ou livre)

def add_bubble(text, sender, pdp_file, image_file=None):

    bubble_outer = tk.Frame(chat_frame, bg="#d9ada2") # Cadre extérieur de la bulle, qui contient tout le message et éventuellement une image

    bubble_outer.pack(fill="x", pady=5) # Place ce cadre dans le chat en largeur totale (fill="x") avec un petit espace vertical (pady=5)


    # Permet de définir l’alignement, la couleur et l’espacement de la "bulle" en fonction de l’expéditeur

    if sender == "bot": # Si c’est le bot qui envoie le message

        anchor_side = "w" # Ancrage à gauche (west) pour placer le message côté gauche

        bubble_color = "#dabcb2" # Couleur de fond de la bulle du bot (beige clair)

        padx_val = 30 # Décalage horizontal pour que la bulle ne touche pas le bord

    else: # Si c’est l’utilisateur

        anchor_side = "e" # Ancrage à droite (east) pour placer le message côté droit

        bubble_color = "#E9D3C5" # Couleur de fond de la bulle de l’utilisateur (rose clair)

        padx_val = 30 # Même décalage horizontal que la bulle du bot pour que ça soit symétrique


    inner_frame = tk.Frame(bubble_outer, bg="#d9ada2") # Cadre à l'intérieur de la bulle principale (bubble_outer) pour organiser l'image et le texte du message

    inner_frame.pack(anchor=anchor_side, padx=padx_val) # Place le cadre (gauche = bot et droite = user) et espace horizontal


    # Permet d’afficher la photo de profil (PDP) du bot et de l’utilisateur à côté du message

    try:

        img = Image.open(pdp_file) # Ouvre le fichier image (photo de profil)

        img = img.resize((40, 40)) # Redimensionne l'image pour qu'elle fasse 40x40 pixels

        photo = ImageTk.PhotoImage(img) # Convertit l'image en format utilisable par Tkinter 

        label_pdp = tk.Label(inner_frame, image=photo, bg="#d9ada2") # Crée un label Tkinter contenant l'image

        label_pdp.image = photo # Nécessaire pour garder une référence à l'image et l'afficher correctement

        label_pdp.pack(side="left" if sender=="bot" else "right", padx=5) # Place la PDP à gauche pour le bot, à droite pour l'utilisateur, avec un petit espace horizontal

    except:

        pass # Si l'image n'existe pas ou qu'il y a une erreur, le programme continue sans planter


    # Permet d’afficher le texte du message dans la bulle

    text_label = tk.Label(

        inner_frame, # Place le texte dans le cadre interne (inner_frame) de la bulle

        text=text, # Le texte à afficher, provenant de l’argument de la fonction

        wraplength=300, # Limite la largeur du texte à 300 pixels et fait un retour à la ligne automatique

        justify="left", # Aligne le texte à gauche à l’intérieur du label

        bg=bubble_color, # Couleur de fond de la bulle (différente selon bot ou utilisateur)

        fg="black", # Couleur du texte (noir)

        padx=10, # Ajoute un petit espace horizontal à l’intérieur du label

        pady=8, # Ajoute un petit espace vertical à l’intérieur du label

        font=("Arial", 12), # Police d’écriture et la taille du texte

        bd=0, # Bordure du label = 0 (pas de bord visible)

        relief="solid" # Relief solide

    ) 

    # Place le label dans le cadre interne à gauche pour le bot, à droite pour l’utilisateur

    text_label.pack(side="left" if sender=="bot" else "right") 


    # Affiche une image associée au message (par exemple la recette ou le livre)

    if image_file:

        try:

            img = Image.open(image_file) # Ouvre le fichier image

            img = img.resize((200, 200)) # Redimensionne l'image à 200x200 pixels

            photo_img = ImageTk.PhotoImage(img) # Convertit l'image pour qu'elle puisse être utilisée par Tkinter

            label_img = tk.Label(bubble_outer, image=photo_img, bg="#d9ada2") # Crée un label contenant l'image

            label_img.image = photo_img # Garde une référence à l'image pour qu'elle s'affiche correctement

            label_img.pack(anchor="center", pady=5) # Place l'image au centre de la bulle, avec un petit espace vertical

        except:

            pass # Si le fichier n'existe pas ou qu'il y a une erreur, le programme continue sans planter


    chat_canvas.update_idletasks() # Force Tkinter à mettre à jour immédiatement tous les changements comme l'ajout de nouvelles bulles ou images

    chat_canvas.yview_moveto(1.0) # Fait défiler le chat vers le bas automatiquement pour afficher le dernier message ajouté


# Fonction qui permet d’envoyer le message de l'utilisateur et afficher la réponse du bot avec les "…"

def send_message():

    user_msg = entry.get() # Récupère le texte que l'utilisateur a écrit dans la zone d'entrée

    if not user_msg.strip():

        return # Si le message est vide ou contient uniquement des espaces, la fonction s'arrête et rien n'est envoyé 

    entry.delete(0, tk.END) # Efface le texte dans la zone d'entrée après avoir récupéré le message

    add_bubble(user_msg, "user", "IMG_3003.jpeg") # Crée une bulle pour le message de l'utilisateur avec sa photo de profil (IMG_3003.jpeg)


    # Crée la bulle du bot avec "…"

    bubble_outer = tk.Frame(chat_frame, bg="#d9ada2") # Crée un cadre extérieur pour la bulle du bot (comme pour add_bubble) avec un fond beige clair

    bubble_outer.pack(fill="x", pady=5) # Place ce cadre dans le chat en largeur totale (fill="x") avec un petit espace vertical entre les messages

    inner_frame = tk.Frame(bubble_outer, bg="#d9ada2") # Crée un cadre interne dans bubble_outer pour organiser le contenu 

    inner_frame.pack(anchor="w", padx=30) # Place le cadre interne à gauche (west) pour le bot et ajoute un espace horizontal de 30 pixels pour que la bulle ne touche pas le bord


    # PDP (photo de profil) du bot

    try:

        img = Image.open("IMG_2996.jpeg") # Ouvre le fichier image de la PDP du bot

        img = img.resize((40, 40)) # Redimensionne l'image à 40x40 pixels

        photo = ImageTk.PhotoImage(img) # Convertit l'image pour qu'elle soit utilisable dans Tkinter

        label_pdp = tk.Label(inner_frame, image=photo, bg="#d9ada2") # Crée un label contenant l'image et fond identique au chat

        label_pdp.image = photo # Garde une référence à l'image pour qu'elle s'affiche correctement

        label_pdp.pack(side="left", padx=5) # Place la PDP à gauche de la bulle du bot avec un petit espace horizontal

    except:

        pass # Si le fichier image n'existe pas ou qu'il y a un problème, le programme continue sans planter


    # Label texte initial avec "…"

    text_label = tk.Label( 

        inner_frame, # Place le label dans le cadre interne de la bulle

        text="…", # Texte "…"

        wraplength=300, # Limite la largeur du texte à 300 pixels pour un retour à la ligne automatique

        justify="left", # Aligne le texte à gauche à l'intérieur du label

        bg="#dabcb2", # Couleur du fond de la bulle du bot

        fg="black", # Couleur du texte

        padx=10, # Marge 

        pady=8, # Marge 

        font=("Arial", 12), # Police d’écriture et taille du texte 

        bd=0, # Pas de bordure autour du label

        relief="solid" # Style du bord (ici plat car bd=0)

    )

    text_label.pack(side="left") # Place le label à gauche dans le cadre (côté bot)


    chat_canvas.update_idletasks() # Permet à la bulle et au texte d’apparaître immédiatement

    chat_canvas.yview_moveto(1.0) # Fait défiler le chat vers le bas pour montrer le dernier message ajouté


    # Fonction qui permet de remplacer les "…" par la vraie réponse du bot après 1,5 seconde

    def show_response():

        bot_reply, img_file = get_response(user_msg) # Récupère la réponse du bot et l'image

        text_label.config(text=bot_reply) # Remplace le "…" par la vraie réponse


        # Permet d’ajouter l'image (par exemple pour "recette" ou "livre")

        if img_file: # Si la réponse du bot contient une image

            try:

                img = Image.open(img_file) # Ouvre le fichier image

                img = img.resize((200, 200)) # Redimension de l'image

                photo_img = ImageTk.PhotoImage(img) # Convertit l'image pour l'afficher dans Tkinter 

                label_img = tk.Label(bubble_outer, image=photo_img, bg="#d9ada2") # Crée un label contenant l'image dans la bulle extérieure

                label_img.image = photo_img # Garde une référence pour éviter que l'image disparaisse 

                label_img.pack(anchor="center", pady=5) # Place l'image au centre avec un petit espace vertical 

            except:

                pass # Si le fichier n'existe pas ou qu'il y a un problème, le programme continue sans planter


        chat_canvas.update_idletasks() # Met à jour l'affichage du chat pour montrer immédiatement les changements

        chat_canvas.yview_moveto(1.0) # Fais défiler automatiquement vers le bas pour afficher le nouveau message


    chat_frame.after(1500, show_response) # Après 1,5 seconde on lance la fonction show_response() pour remplacer "…" par la vraie réponse


# Interface graphique

root = tk.Tk() # Permet de crée  la fenêtre principale

root.title("Chat with Mango") # Titre affiché en haut de la fenêtre

root.geometry("500x600") # Taille de la fenêtre, largeur 500px, hauteur 600px

root.configure(bg="#d9ada2") # Couleur du fond 


# Titre du chatbot

title_label = tk.Label(

    root, # Fenêtre principale dans laquelle on place le titre 

    text="Chat with Mango", # Texte affiché en haut de la fenêtre

    font=("Georgia", 20, "bold"), # Police d’écriture Georgia, taille 20 en gras

    bg="#d9ada2", # Couleur de fond du label

    fg="#bb7f82" # Couleur du texte (titre)

)

title_label.pack(pady=10) # Affiche le titre + marge verticale de 10px

# Zone où s'affichent les messages 

# Création d'un cadre "container" qui contient le Canvas et la scrollbar
chat_frame_container = tk.Frame(root, bg="#d9ada2") # root : fenêtre principale dans laquelle on place ce container # bg : couleur de fond du container

# pack() positionne ce container dans la fenêtre 
# fill="both" s'étire en largeur et hauteur pour occuper l'espace disponible 
# expand=True permet au container de recevoir l'espace restant si la fenêtre est redimensionné 
# padx/pady marges (espace entre le bord de la fenêtre et le container)
chat_frame_container.pack(fill="both", expand=True, padx=10, pady=10) 

# Canvas, permet de faire défiler les messages verticalement 
chat_canvas = tk.Canvas(chat_frame_container, bg="#d9ada2", bd=0, highlightthickness=0) # Canvas, permet de faire défiler les messages verticalement # retire le trait bleu contour que Tkinter met parfois

# Barre de défilement verticale
scrollbar = tk.Scrollbar(chat_frame_container, orient="vertical", command=chat_canvas.yview) # orient="vertical" donc orientation vertical 

chat_canvas.configure(yscrollcommand=scrollbar.set) # On connecte le canvas à la scrollbar, le canvas doit appeler scrollbar.set, pour que scrollbar suive le défilement

# Place la scrollbar à droite et le canvas à gauche
scrollbar.pack(side="right", fill="y")

chat_canvas.pack(side="left", fill="both", expand=True)

# Frame interne où seront placées toutes les bulles de messages, on la place à l'intérieur du canvas (plutôt que directement dans le container) pour avoir le scrolling automatique
chat_frame = tk.Frame(chat_canvas, bg="#d9ada2")

chat_canvas.create_window((0, 0), window=chat_frame, anchor="nw") # Ajoute la frame interne dans le canvas


def on_frame_configure(event): # Cette fonction met à jour la zone de scroll quand du contenu est ajouté, c’est une fonction  de rappel. Sans cette mise à jour le canvas ne "sait" pas quelle zone il doit faire défiler.

    chat_canvas.configure(scrollregion=chat_canvas.bbox("all"))

chat_frame.bind("<Configure>", on_frame_configure) # Dès que la taille de chat_frame change, on met à jour le scroll


# Zone de saisie et bouton pour envoyer les messages

entry = tk.Entry(root, font=("Arial", 14)) # Crée une zone de texte où l'utilisateur peut écrire son message # root : la fenêtre principale dans laquelle on place l'entrée # font=("Arial", 14) : police d’écriture Arial taille 14 pour le texte

entry.pack(padx=10, pady=10, fill="x") # padx/pady : ajoute un espace autour de la zone de texte (horizontal et vertical) # fill="x" : permet à l'entrée de s'étirer horizontalement

# bouton qui permet d'envoyer le message
send_btn = tk.Button(root, text="Envoyer", font=("Arial", 12), bg="#dabcb2", command=send_message) # text="Envoyer" : texte affiché sur le bouton # font=("Arial", 12) : police et taille du texte sur le bouton # bg="#dabcb2" : couleur de fond du bouton

send_btn.pack(pady=5)


# Message d’accueil du bot

add_bubble("Bonjour je suis Mango, je suis là pour t’aider !", "bot", "IMG_2996.jpeg")


root.mainloop() # Boucle principale de Tkinter qui permet de garder la fenêtre ouverte et gère les actions de l’utilisateur (cliquer sur un bouton, écrire du texte dans l’entrée, faire défiler le chat, fermer la fenêtre)